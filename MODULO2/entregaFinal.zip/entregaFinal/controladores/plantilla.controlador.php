<?php

Class ControladorPlantilla{



	public function ctrGetPlantilla(){

		include "vistas/plantilla.php";

	}

}