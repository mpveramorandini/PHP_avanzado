<h1 class="tituloPagina">Registro</h1>

<div class="contacto">

    <form action="" method="post" class="formulario">
        
            <p>
                <label for="nombre">Usuario:</label>
                <input type="text" name="registroNombre" id="nombre">
            </p>
            <p>
                <label for="email">Email:</label>
                <input type="text" name="registroEmail" id="email">
            </p>
            <p>
                <label for="pwd">Contraseña</label>
                <input type="password" name="registroPassword" id="pwd">
            </p>
        

            <?php
                $registro = ControladorFormularios::ctrRegistro();

                ?>
           <p class="boton">
            <input type="submit" name="" id="enviar" value="enviar">
        </p>

        </form>
    </div>